#! /bin/sh

# test mode
srs_control SETVALUE 6039 0x00 0 0x03
#sleep 1

# n = 4
srs_control SETVALUE 6039 0x01 0 0x09
#sleep 1

# frequency 
srs_control SETVALUE 6039 0x02 0 0xea60
#sleep 1

# APV delay
srs_control SETVALUE 6039 0x03 0 255
#srs_control SETVALUE 6039 0x03 0 100
#sleep 1

# test pulse delay
srs_control SETVALUE 6039 0x04 0 0x80
#sleep 1

# RO_SYNC
srs_control SETVALUE 6039 0x05 0 350
#srs_control SETVALUE 6039 0x05 0 0
#sleep 1

# channel mask
srs_control SETVALUE 6039 0x08 0 0x055
#srs_control SETVALUE 6039 0x08 0 0x0040
#sleep 1

# capture window
srs_control SETVALUE 6039 0x09 0 0xFD2
#sleep 1

# EVB Mode
srs_control SETVALUE 6039 0x0a 0 0x00
#sleep 1

# event info type
srs_control SETVALUE 6039 0x0b 0 0x00
#sleep 1

# evt info marker
srs_control SETVALUE 6039 0x0c 0 0xaabb0bb8
#sleep 1
