#! /bin/sh


if ! rcdaq_client daq_status > /dev/null 2>&1 ; then

    echo "No rcdaq_server running, starting..."
    rcdaq_server > $HOME/log/rcdaq.log 2>&1 & 
    sleep 2

    ELOG=$(which elog 2>/dev/null)
    [ -n "$ELOG" ]  && rcdaq_client elog localhost 666 RCDAQLog


fi


# --RCDAQGUI

# --SC Top Level setup script for reading out the SRS

# --LC This setup script sets up the readout of the SRS crate.
# --LC this script adds itself to teh begin-run event as packet 900.
# --LC it also adds the readout of the apv to the begin-run, 
# --LC by way of issuing a command and then reading the file. 

# we need the $0 as absolute path b/c we pass it on to a "file" device further down
D=`dirname "$0"`
B=`basename "$0"`
MYSELF="`cd \"$D\" 2>/dev/null && pwd || echo \"$D\"`/$B"


rcdaq_client daq_setrunnumberfile $HOME/.last_rcdaq_runnumber.txt

if ! rcdaq_client daq_status -l | grep -q "SRS Plugin" ; then

    echo "SRS plugin not loaded yet, loading..."
    rcdaq_client load librcdaqplugin_srs.so
fi


rcdaq_client daq_clear_readlist

# we add this very file to the begin-run event
rcdaq_client create_device device_file 9 900 $MYSELF

rcdaq_client create_device device_command 9 0 "srs_control readapv > $HOME/apv.txt"
rcdaq_client create_device device_file 9 910  $HOME/apv.txt

#rcdaq_client daq_define_runtype beam    /data/gem/beam/beam_%010d-%04d.evt
#rcdaq_client daq_define_runtype junk    /data/gem/junk/junk_%010d-%04d.evt
#rcdaq_client daq_define_runtype calibration /data/gem/calibration/calibration_%010d-%04d.evt
#rcdaq_client daq_define_runtype pedestal /data/gem/pedestal/pedestal_%010d-%04d.evt

#rcdaq_client daq_setruntype junk

rcdaq_client create_device device_srs 1 1010 10.0.0.2 1

rcdaq_client daq_list_readlist

