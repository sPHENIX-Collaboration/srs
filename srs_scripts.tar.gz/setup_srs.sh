#! /bin/sh

if [ -n "$1" ] ; then

# first we reset the FEC  (Table 3)

    echo "resetting FEC..."
    srs_control SETVALUE 6007 0xffffffff 0  0xffff8000
    
    echo -n "waiting for the card to get out of reset " 
    sleep 2
    
    while ! ping -c 1 -n  10.0.0.2 >/dev/null 2>&1;  do 
	echo -n " ."
	sleep 1
    done
    sleep 1

fi

sh initialize_ADCCARD.sh
sh initialize_FEC.sh


#./srs_control EVBLD_CHMASK 0x5
#./srs_control EVBLD_DATALENGTH 4000
#./srs_control BLCK_TRGBURST 8
#./srs_control BCLK_FREQ 0xfff0
 
sh initialize_HYBRID.sh

#./srs_control SETVALUE 6039 0xffffffff 0  0xffff0001

#./srs_control BLCK_MODE 3
#./srs_control RO_ENABLE


