#! /bin/sh

for c in `seq 0 6` ; do
    srs_control GETVALUE 6519 $c  0
done

# reset ADC card registers
srs_control SETVALUE 6519 0 0 0x00

srs_control SETVALUE 6519 1 0 0x00
srs_control SETVALUE 6519 2 0 0x00
srs_control SETVALUE 6519 3 0 0x00
srs_control SETVALUE 6519 4 0 0x00
srs_control SETVALUE 6519 5 0 0x00
srs_control SETVALUE 6519 6 0 0xff

# de-reset all APVs
srs_control SETVALUE 6519 0 0 0xff


for c in `seq 0 6` ; do
    srs_control GETVALUE 6519 $c  0
done



